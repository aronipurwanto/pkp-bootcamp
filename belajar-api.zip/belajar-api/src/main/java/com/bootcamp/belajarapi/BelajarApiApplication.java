package com.bootcamp.belajarapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BelajarApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BelajarApiApplication.class, args);
	}

}
